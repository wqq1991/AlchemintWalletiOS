//SmartContract003 GetTransaction
var nnc = "0x3fccdb91c9bb66ef2446010796feb6ca4ed96b05"
var prikey = ThinNeo.Helper.GetPrivateKeyFromWIF("L3tDHnEAvwnnPE4sY4oXpTvNtNhsVhbkY4gmEmWmWWf1ebJhVPVW");
var pubkey = ThinNeo.Helper.GetPublicKeyFromPrivateKey(this.prikey);
var address = ThinNeo.Helper.GetAddressFromPublicKey(this.pubkey);
var toaddr = "APwCdakS1NpJsiq6j9SfvkQFS9ubt347a2";
var id_GAS = "0x602c79718b16e442de58778e148d0b1084e3b2dffd5de6b7b16cee7969282de7";

async function rawTransaction(){
    
    alert("o");
    
    var utxos = await getutxo();
    var pkeyhash = ThinNeo.Helper.GetPublicKeyScriptHashFromPublicKey(pubkey);
    let targeraddr = address;  //Transfer it to yourself. 
    let tran = makeTran(getassets(utxos), targeraddr, id_GAS, Neo.Fixed8.Zero);
    tran.type = ThinNeo.TransactionType.InvocationTransaction;
    tran.extdata = new ThinNeo.InvokeTransData();
    let script = null;

    var sb = new ThinNeo.ScriptBuilder();

    var scriptaddress = nnc.hexToBytes().reverse();
    //Parameter inversion 
    sb.EmitParamJson(["(address)" + address, "(address)" + toaddr, "(integer)" + 1]);//Parameter list 
    sb.EmitPushString("transfer");//Method
    sb.EmitAppCall(scriptaddress);  //Asset contract 
    (tran.extdata).script = sb.ToArray();
    (tran.extdata).gas = Neo.Fixed8.fromNumber(1.0);
    var msg = tran.GetMessage();
    var signdata = ThinNeo.Helper.Sign(msg, prikey);
    tran.AddWitness(signdata, pubkey, address);
    let txid = tran.GetHash().clone().reverse().toHexString();
    var data = tran.GetRawData();

    var scripthash = data.toHexString();
    var api = "http://47.96.168.8:20332";
    var postdata = makeRpcPostBody("sendrawtransaction", scripthash);
    var result = await fetch(api, { "method": "post", "body": JSON.stringify(postdata) });
    var json = await result.json();    
    var r = json["result"];
    console.log("got=" + JSON.stringify(json));
    document.getElementById("app").innerText=JSON.stringify(json);
    if(r){
        alert(txid);
    }

}


//tools
function makeRpcUrl(url, method) {
    var _params = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        _params[_i - 2] = arguments[_i];
    }
    if (url[url.length - 1] != '/')
        url = url + "/";
    var urlout = url + "?jsonrpc=2.0&id=1&method=" + method + "&params=[";
    for (var i = 0; i < _params.length; i++) {
        urlout += JSON.stringify(_params[i]);
        if (i != _params.length - 1)
            urlout += ",";
    }
    urlout += "]";
    return urlout;
}

async function getutxo(){
    var api = "http://47.96.168.8:81/api/testnet";
    var str = makeRpcUrl(api, "getutxo", address);    
    var result = await fetch(str, { "method": "get" });
    var json = await result.json();
    var r = json["result"];
    return r;
}

function makeTran(utxos, targetaddr, assetid, sendcount)
{
    //if (sendcount.compareTo(Neo.Fixed8.Zero) <= 0)
    //    throw new Error("can not send zero.");
    var tran = new ThinNeo.Transaction();
    tran.type = ThinNeo.TransactionType.ContractTransaction;
    tran.version = 0;//0 or 1
    tran.extdata = null;

    tran.attributes = [];

    tran.inputs = [];
    var scraddr = "";
    utxos[assetid].sort((a, b) =>
    {
        return a.count.compareTo(b.count);
    });
    var us = utxos[assetid];
    var count = Neo.Fixed8.Zero;
    for (var i = 0; i < us.length; i++)
    {
        var input = new ThinNeo.TransactionInput();
        input.hash = us[i].txid.hexToBytes().reverse();
        input.index = us[i].n;
        input["_addr"] = us[i].addr;//利用js的隨意性，臨時傳個值
        tran.inputs.push(input);
        count = count.add(us[i].count);
        scraddr = us[i].addr;
        if (count.compareTo(sendcount) > 0)
        {
            break;
        }
    }
    if (count.compareTo(sendcount) >= 0)//输入大于等于输出
    {
        tran.outputs = [];
        //输出
        if (sendcount.compareTo(Neo.Fixed8.Zero) > 0)
        {
            var output = new ThinNeo.TransactionOutput();
            output.assetId = assetid.hexToBytes().reverse();
            output.value = sendcount;
            output.toAddress = ThinNeo.Helper.GetPublicKeyScriptHash_FromAddress(targetaddr);
            tran.outputs.push(output);
        }

        //找零
        var change = count.subtract(sendcount);
        if (change.compareTo(Neo.Fixed8.Zero) > 0)
        {
            var outputchange = new ThinNeo.TransactionOutput();
            outputchange.toAddress = ThinNeo.Helper.GetPublicKeyScriptHash_FromAddress(scraddr);
            outputchange.value = change;
            outputchange.assetId = assetid.hexToBytes().reverse();
            tran.outputs.push(outputchange);

        }
    }
    else
    {
        throw new Error("no enough money.");
    }
    return tran;
}

function makeRpcPostBody(method, ..._params)
{
    var body = {};
    body["jsonrpc"] = "2.0";
    body["id"] = 1;
    body["method"] = method;
    var params = [];
    for (var i = 0; i < _params.length; i++)
    {
        params.push(_params[i]);
    }
    body["params"] = params;
    return body;
}

function getassets(utxos)
{
    var assets = {};
    for (var i in utxos)
    {
        var item = utxos[i];
        var txid = item.txid;
        var n = item.n;
        var asset = item.asset;
        var count = item.value;
        if (assets[asset] == undefined)
        {
            assets[asset] = [];
        }
        var utxo = {
            addr:item.addr,
            asset:asset,
            n:n,
            txid:txid,
            count:Neo.Fixed8.parse(count+"")
        };
        assets[asset].push(utxo);
    }
    return assets;
}
